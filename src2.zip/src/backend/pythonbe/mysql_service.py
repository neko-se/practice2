from flask import Flask, render_template, flash, request, redirect, url_for, jsonify
from datetime import datetime 
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import MetaData, Table, Column, Integer, String, select, create_engine, DateTime
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
#from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash 
from datetime import date
#from webforms import LoginForm, PostForm, UserForm, PasswordForm, NamerForm, SearchForm
# from flask_login import UserMixin, login_user, LoginManager, login_required, logout_user, current_user
# from webforms import LoginForm, PostForm, UserForm, PasswordForm, NamerForm
# from flask_ckeditor import CKEditor
from werkzeug.utils import secure_filename
import uuid as uuid
import os
from flask_cors import CORS


# Create a Flask Instance
app = Flask(__name__)
CORS(app)

# Add CKEditor
# ckeditor = CKEditor(app)
# Add Database
# Old SQLite DB
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
# app.config['SQLALCHEMY_DATABASE_URI'] = 'postgres://fvmdxyjigwbmiu:d31d36c7613e08f7ad37a6e40007189d7f2f44fbc99234b339994780a122d870@ec2-3-214-190-189.compute-1.amazonaws.com:5432/d17b5scj97ckqe'
# New MySQL DB
#app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root@localhost/testsqlalchemy'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:root@localhost/testsqlalchemy'
# Secret Key!
# app.config['SECRET_KEY'] = "my super secret key that no one is supposed to know"
# Initialize The Database

UPLOAD_FOLDER = 'static/images/'
#app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

#db = SQLAlchemy()
#migrate = Migrate(app, db)
#db.init_app(app)
#metadata_obj = MetaData()
Base = declarative_base()

# define tickets table
# tickets_table = Table('tbl_tickets', Base.metadata,
# 	Column("ticket_id", Integer, primary_key=True),
#     Column("escalation", String(255)),
#     Column("ticket_link", String(255)),
#     Column("priority", String(255)),
# )

# Create a Ticket model
class Ticket(Base):
	__tablename__ = 'tbl_tickets'

	ticket_id = Column("escalation", Integer, primary_key=True)
	escalation = Column("escalation", String)
	ticket_link = Column("ticket_link", String)
	priority = Column("priority", String)
	status = Column("status", String)
	title = Column("title", String)
	summary = Column("summary", String)
	primary_agent = Column("primary_agent", String)
	date_received = Column("date_received", DateTime)
	date_lastmod = Column("date_lastmod", DateTime)

	def __init__(self, ticket_id):
		self.ticket_id = ticket_id

	def __repr__(self):
		return f"({self.ticket_id}) {self.title}"

engine = create_engine("mysql+pymysql://root:root@localhost/testsqlalchemy")
metadata = MetaData()

# session factory
Session = sessionmaker(bind=engine)
session = Session()

#@app.route('/api/tickets')
def posts():
	# Grab all the tickets from the database
	#tickets = Ticket.query.order_by(Ticket.date_received)
	# ticketlist = select(tickets)
	# stmt = select(tickets).where(
    #             and_(
    #                 tickets.c.ticket_id == 51673
	# 				# add here for other filters (if needed)
    #             )
    #         )
	result = session.query(Ticket).all()

	print("ticketlist")
	print(result)
	return jsonify(result)
	#return render_template("posts.html", posts=posts)

if __name__ == '__main__':
    app.run()
