from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy.engine import Row

Base = automap_base()
engine = create_engine('mysql+pymysql://root:root@localhost/testsqlalchemy', pool_pre_ping=True)

# reflect the existing tables from database
Base.prepare(autoload_with=engine)

# Define tbl_ticket table as Ticket model
Ticket = Base.classes.tbl_ticket

# generate session
session = Session(engine)

# run query
# q = session.query(Ticket).all()
result = session.query(Ticket).filter(Ticket.ticket_id == 51674)

# e.g return this as a rest-api response
tickets = [row.__dict__ for row in result]
print(tickets)
