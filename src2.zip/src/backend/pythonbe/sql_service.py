from flask import Flask, render_template, flash, request, redirect, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import MetaData, Table, Column, Integer, String, select, create_engine, DateTime
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
import os
from flask_cors import CORS
import json
import dataclasses

# Create a Flask Instance
app = Flask(__name__)
CORS(app)

# automap base
Base = automap_base()

# pre-declare User for the 'user' table
@dataclasses.dataclass
class Ticket(Base):
	__tablename__ = 'tbl_ticket'
	
	# override schema elements like Columns
	ticket_id = Column('ticket_id', Integer, primary_key=True)
	escalation = Column('escalation', String)
	ticket_link = Column('ticket_link', String)
	priority = Column('priority', String)
	status = Column('status', String)
	title = Column('title', String)
	summary = Column('summary', String)
	date_received = Column('date_received', DateTime)
	date_lastmod = Column('date_lastmod', DateTime)

	def as_dict(self):
		return {item.name: getattr(self, item.name) for item in self.__table__.columns}


# reflect
engine = create_engine('mysql+pymysql://root:root@localhost/testsqlalchemy', pool_pre_ping=True)

# reflect the existing tables from database
Base.prepare(autoload_with=engine)

@app.route('/api/tickets')
def posts():
	# generate session
	session = Session(engine)
	result = session.query(Ticket).all()
	#result = session.query(Ticket).filter(Ticket.ticket_id == 51674)

	tickets=[]
	for ticket in result:
		tickets.append(ticket.as_dict())

	session.close()
	return jsonify(tickets)

if __name__ == '__main__':
    app.run()

