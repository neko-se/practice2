class TicketModel:
    def __init__(self, ticket_id, escalation, ticket_link, priority, status, title, summary, date_received, date_lastmod, primary_agent):
        self.ticket_id = ticket_id
        self.escalation = escalation
        self.ticket_link = ticket_link
        self.priority = priority
        self.status = status
        self.title = title
        self.summary = summary
        self.date_received = date_received
        self.date_lastmod = date_lastmod
        self.primary_agent = primary_agent

    def __repr__(self):
      return f"TicketModel('{self.ticket_id}', {self.title})"