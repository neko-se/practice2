import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ApiserviceService } from '../backend/apiservice.service';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit{
  title = 'angularwithbe';
  newdata:any;

  constructor(private _apiservice:ApiserviceService) { }

  ngOnInit() {
    this.getData();
  }

  getData() {
    this._apiservice.getdata().subscribe(res=>{
      this.newdata=res;
      if(this.newdata == undefined)
      {
        console.log("Failed to get python data");
      }
    })
  }
}
